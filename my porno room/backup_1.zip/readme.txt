Backup time: 2026-09-02 at 04:58:40 UTC
ServerName: pzserver
Current server version:42.20
Current world version:249
World version in this backup is:249